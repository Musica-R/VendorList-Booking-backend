import vendorSettlementModel from "../models/vendorSettlementModel.js";
import db from "../config/db.js";

export const checkAndCreateVendorSettlement = (bookingId) => {

    vendorSettlementModel.getBookingSettlementData(
        bookingId,
        (err, result) => {

            if (err || result.length === 0) {
                return;
            }

            const booking = result[0];

            // Booking must be completed
            if (booking.booking_status !== "completed") {
                return;
            }

            // Advance must be paid
            if (booking.payment_status !== "paid") {
                return;
            }

            // Balance must be paid
            if (booking.balance_payment_status !== "paid") {
                return;
            }

            // Both payments must be settled
            if (
                Number(booking.payment_count) !==
                Number(booking.settlement_count)
            ) {
                return;
            }

            vendorSettlementModel.checkVendorSettlementExists(
                bookingId,
                (err2, existing) => {

                    if (err2) return;

                    if (existing.length > 0) {
                        return;
                    }

                    const totalReceived =
                        Number(booking.total_received);

                    const commission =
                        +(totalReceived * 0.10).toFixed(2);

                    const vendorAmount =
                        +(totalReceived - commission).toFixed(2);

                    vendorSettlementModel.createVendorSettlement(
                        bookingId,
                        booking.vendor_id,
                        totalReceived,
                        commission,
                        vendorAmount,
                        (err3) => {

                            if (err3) {
                                console.log(err3);
                                return;
                            }

                            console.log(
                                `Vendor settlement created for booking ${bookingId}`
                            );
                        }
                    );
                }
            );
        }
    );
};

export const getAllCompletedVendorSettlements = (req, res) => {
  const sql = `
    SELECT
      vs.id AS settlement_id,
      vs.booking_id,
      vs.vendor_id,

      v.full_name AS vendor_name,
      v.phone AS vendor_phone,
      v.shop_name,
      V.upi_id,

      u.name AS user_name,
      u.phone AS user_mobile,
      

      b.booking_number,
      b.total_amount,
      b.booking_status,
      b.payment_status,
      b.balance_payment_status,

      COALESCE(adv.advance_paid, 0) AS advance_paid,
      COALESCE(bal.balance_paid, 0) AS balance_paid,
      (COALESCE(adv.advance_paid, 0) + COALESCE(bal.balance_paid, 0)) AS total_paid_user,

      COALESCE(rs.total_received, 0) AS razorpay_settlement,
      COALESCE(rs.total_fee, 0) AS razorpay_fee,
      COALESCE(rs.total_tax, 0) AS razorpay_tax,

      vs.total_received,
      vs.platform_commission_percent,
      vs.platform_commission_amount,
      vs.vendor_amount,

      vs.settlement_status,
      vs.settled_at,
      vs.created_at

    FROM vendor_settlements vs

    JOIN bookings b ON b.id = vs.booking_id
    JOIN vendors v ON v.id = vs.vendor_id
    JOIN users u ON u.id = b.user_id

    LEFT JOIN (
      SELECT booking_id, SUM(amount) AS advance_paid
      FROM payments
      WHERE payment_type = 'advance'
      GROUP BY booking_id
    ) adv ON adv.booking_id = b.id

    LEFT JOIN (
      SELECT booking_id, SUM(amount) AS balance_paid
      FROM payments
      WHERE payment_type = 'balance'
      GROUP BY booking_id
    ) bal ON bal.booking_id = b.id

    LEFT JOIN (
      SELECT
        booking_id,
        SUM(net_amount) AS total_received,
        SUM(fee) AS total_fee,
        SUM(tax) AS total_tax
      FROM razorpay_settlements
      GROUP BY booking_id
    ) rs ON rs.booking_id = b.id

    WHERE vs.settlement_status = 'pending'
      AND b.booking_status = 'completed'

    ORDER BY vs.created_at DESC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: "Database error",
        error: err,
      });
    }

    return res.status(200).json({
      success: true,
      data: results,
    });
  });
};