import db from "../config/db.js";

const getBookingSettlementData = (bookingId, callback) => {
  const sql = `
    SELECT
      b.id,
      b.vendor_id,
      b.booking_status,
      b.payment_status,
      b.balance_payment_status,

      (SELECT COUNT(*) FROM payments p WHERE p.booking_id = b.id) AS payment_count,

      (SELECT COUNT(*) FROM razorpay_settlements rs WHERE rs.booking_id = b.id) AS settlement_count,

      COALESCE((
        SELECT SUM(rs.net_amount)
        FROM razorpay_settlements rs
        WHERE rs.booking_id = b.id
      ), 0) AS total_received

    FROM bookings b
    WHERE b.id = ?
  `;

  db.query(sql, [bookingId], callback);
};

const checkVendorSettlementExists = (bookingId, callback) => {
  const sql = `
    SELECT id
    FROM vendor_settlements
    WHERE booking_id = ?
  `;

  db.query(sql, [bookingId], callback);
};

const createVendorSettlement = (
  bookingId,
  vendorId,
  totalReceived,
  commission,
  vendorAmount,
  callback
) => {
  const sql = `
    INSERT INTO vendor_settlements (
      booking_id,
      vendor_id,
      total_received,
      platform_commission_amount,
      vendor_amount
    )
    VALUES (?, ?, ?, ?, ?)
  `;

  db.query(
    sql,
    [
      bookingId,
      vendorId,
      totalReceived,
      commission,
      vendorAmount,
    ],
    callback
  );
};

export default {
  getBookingSettlementData,
  checkVendorSettlementExists,
  createVendorSettlement,
};