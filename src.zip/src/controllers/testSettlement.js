import { checkAndCreateVendorSettlement } from "../controllers/vendorSettlementController.js"

checkAndCreateVendorSettlement(2);